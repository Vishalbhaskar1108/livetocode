<html>
	<head>
		<title>Lavi Cabs</title>
		<link rel="icon" type="image/png" href="car/a1.png">
		<style>
			#d1
			{
				width:1370px;
				height:90px;
				background-color:#0a8692;
				margin-left:-10px;
				margin-top:-100px;
				}
			#p1{
				font-family:Monotype Corsiva;
				font-size:80px;
				text-align:center;
				margin-top:100px;
				text-shadow:1px 1px white;
			}
			#d2
			{
				width:1370px;
				height:2px;
				background-color:black;
				margin-left:-10px;
				}
			#d3{
				width:1370px;
				height:590px;
				margin-left:-10px;
				background-image:url('car/Taxi.jpg');
				}
			#d4{
				width:370px;
				height:550px;
				background-color:rgba(230, 230, 250,0.9);
				margin-left:500px;
				margin-top:10px;
				border-radius:15px;border-style:solid;border-width:1px;
				}
			#p2{
				text-align:center;
				font-family:Arial;
				font-size:25px;
				}
			label{
				font-size:20px;
				margin-left:10px;
				
				}
			input[type=text],input[type=password] {
				width: 100%;
				padding: 12px 20px;
				margin: 8px 0;
				display: inline-block;
				border: 1px solid #ccc;
				border-radius: 4px;
				box-sizing: border-box;
				}
			input[type=submit]{
				background-color: #4CAF50;
				border: none;
				color: white;
				padding: 16px 32px;
				text-decoration: none;
				margin: 4px 2px;
				cursor: pointer;
				}
			input[type=submit]:hover{
				background-color:#145C16;
				}
			
			#b2{
				margin-left:135px;
				margin-top:10px;
				}
		</style>
		<?php
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$id = $_POST['id'];
			$pass = $_POST['pass'];
			$num = $_POST['numb'];
			$pass1="";

			$conn = new mysqli("localhost", "root", "", "lavi_cabs");
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			$sql1 = "SELECT pass from driver where id='". $id ."';";
			$result1 = $conn->query($sql1);
			$row1 = $result1->fetch_assoc();
			$pass1=$row1["pass"];
			if($pass==$pass1)
			{
				$sql2 = "UPDATE driver SET available=1 WHERE id='". $id ."';";
				$conn->query($sql2);
				$sql3 = "UPDATE cab SET available=1 WHERE cabnumber='". $num ."';";
				$conn->query($sql3);
				echo '<script language="javascript">';
				echo 'alert("done")';
				echo '</script>';
			}
			else
			{
				echo '<script language="javascript">';
				echo 'alert("Password Incorrect")';
				echo '</script>';
			}
			
			

			$conn->close();
			}
		?>
	</head>
	<body>
		<div id="d1">
			<p id="p1">Welcome Driver</p>
		</div>
		<div id="d2">
		</div>
		<div id="d3">
		<br>
			<div id="d4">
				<p id="p2">Enter the Details</p>
				<div id="d5">
				<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
					<label>Unique Id:</label><input type="text" name="id" autofocus placeholder="Enter your unique ID" pattern="[A-Z0-9]*"></input><br><br>
					<label>Password:</label><input type="password" name="pass" placeholder="Enter your password" ></input><br><br>
					<label>Taxi Number:</label><input type="text" name="numb" placeholder="Enter your Taxi Number"></input><br><br>
					<label>Destination:</label><input type="text" name="dest" placeholder="Enter your Destination"></input><br>
					<input id="b2" type="submit" value="I'm back">
				</form>
				</div>
				
			</div>
		</div>
	</body>
</html>