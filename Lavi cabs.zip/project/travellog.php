<html>
	<head>
	<style>
	
	#d1{

	width:100%;
	height:10%;
	background-color:rgba(0, 0, 102,0.9);
	}
	body{
		background:url('car/back3.jpg');
		background-attachment:fixed;
		background-size:cover;
	}
	#s1{
	position:absolute;
	color:red;
	font-family:Lucida Calligraphy;
	font-size:40px;
	text-shadow:1px 1px white;
	margin-left:38%;
	margin-top:0.4%;
	}
	#d2{
	position:absolute;
	width:80%;
	height:80%;
	background-color:rgba(217, 217, 217,0.85);
	margin-top:3%;
	margin-left:9%;
	
	}
	th{
	font-family:High Tower Text;
	font-size:20px;
	padding-top:15px;
	padding-left:45px;
	text-decoration:underline;
	}
	td{
	font-family:High Tower Text;
	font-size:20px;
	padding-top:15px;
	padding-left:45px;
	}
	</style>
	</head>
	<body>
		<div id="d1">
		<span id="s1">Travel Log</span>
		</div>
		<div id="d2">
		<table>
		<tr>
		<th>Passenger Name</th>
		<th>Driver ID</th>
		<th>Taxi Number</th>
		<th>Source</th>
		<th>Destination</th>
		<th>Cost</th>
		<th>Date</th>
		<th>Time</th>
		</tr>
		<?php
	 

			$conn = new mysqli("localhost", "root", "", "lavi_cabs");
			
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
			$sql = "SELECT * from travellog";
			$result = $conn->query($sql);
			while($row = $result->fetch_assoc()) {
		?>
		<tr>
		<td><?php echo($row["passenger"]) ?></td>
		<td><?php echo($row["driverid"]) ?></td>
		<td><?php echo($row["taxinum"]) ?></td>
		<td><?php echo($row["source"]) ?></td>
		<td><?php echo($row["destination"]) ?></td>
		<td><?php echo($row["cost"]) ?></td>
		<td><?php echo($row["date1"]) ?></td>
		<td><?php echo($row["time1"]) ?></td>
		</tr>
		<?php
		}
		$conn->close();
		?>
		</table>
		</div>
		
	</body>
</html>