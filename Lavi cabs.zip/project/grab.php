<html>
	<head>
		<title>Lavi Cabs</title>
		<link rel="icon" type="image/png" href="car/a1.png">
		<style>
		#d1{
			background-color:black;
			width:102%;
			height:4px;
			margin-left:-8px;
			margin-top:-10px;
			}
		#d2{
			background-color:#4000FF;
			width:102%;
			height:100px;
			margin-left:-8px;
			border-bottom:solid 1px;
			}
		#d3{
			color:#B40404;
			font-size:400%;
			text-align:center;
			font-family:Lucida Calligraphy;
			padding-top:10px;
			text-shadow:2px 2px #FFFF00;
			}
		#d4{
			background-image:url('car/grab.jpg');
			width:102%;
			height:100%;
			margin-left:-8px;
			}
		#d5{
			width:28%;
			height:95%;
			background-color:rgba(224, 239, 243,0.85);
			margin-left:500px;
			border-radius:15px 30px 15px 30px;border-style:solid;border-width:1px;
			}
		#p1{
			text-align:center;
			font-size:180%;
			font-weight:bold;
			font-family:Informal Roman;
			margin-top:3%;
			}
		label{
				font-size:150%;
				margin-left:10px;
				font-family:Monotype Corsiva
				}
		input[type=text],select{
				width: 100%;
				padding: 12px 20px;
				margin: 8px 0;
				display: inline-block;
				border: 1px solid #ccc;
				border-radius: 4px;
				box-sizing: border-box;
				font-weight:bold;
				font-family:Comic Sans MS;
				}
			option{
				font-family:Comic Sans MS;
				font-weight:bold;
				}
			#d6{
				margin-top:-10px;
				}
			#b1,#b2{
				position:absolute;
				background-color: #4CAF50;
				border: none;
				color: white;
				padding: 16px 32px;
				text-decoration: none;
				cursor: pointer;
				margin-left:130px;
				margin-top:30px;
				
				}
			#b2{
			margin-top:14px;
			display:block;
			}
			
			#b1{
				display:none;
			}
			#i5{
				display:none;
			}
			
		</style>
		<script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
		<script>
		function dis1(){
		
		var a=document.getElementById("i2").value;
		var b=document.getElementById("i3").value;
		var directionsService = new google.maps.DirectionsService();
		var dist;
		var request = {
		origin      : a, // a city, full address, landmark etc
		destination : b,
		travelMode  : google.maps.DirectionsTravelMode.DRIVING
		};

		directionsService.route(request, function(response, status) {
		if ( status == google.maps.DirectionsStatus.OK ) {
			dist=Math.floor((response.routes[0].legs[0].distance.value)/1000); 
			document.getElementById("i5").value=dist;
		}
		else {
			document.getElementById("i5").value=137;
		}
		document.getElementById("b1").style.display="block";
		document.getElementById("b2").style.display="none";
		});}
		</script>
	</head>
	<body>
		<div id="d1">
		</div>
		<div id="d2">
			<div id="d3">
			Welcome Traveller!!
			</div>
		</div>
		<div id="d4">
			<br><br><div id="d5">
				<p id="p1">Fill in the Details to Grab Now!!</p>
				<div id="d6">
					<form method="post" action="recieve.php">
					<label>Name:</label><input id="i1" type="text" name="name" autofocus placeholder="Enter passenger's name" pattern="[A-Za-z]*"></input><br>
					<label>Source:</label><input id="i2" type="text" name="source" placeholder="Enter pickup location" ></input><br>
					<label>Destination:</label><input id="i3" type="text" name="destination" placeholder="Enter your Destination"></input><br>
					<label>Choose the cab type you want:</label>
					<select id="i4" name="cabtype">
						<option value="mini">Mini</option>
						<option value="micro">Micro</option>
						<option value="sedan">Sedan</option>
						<option value="suv">SUV</option>
						<option value="lux">LUX</option>
					</select><br>
					<input id="i5" type="text" name="distance" placeholder="distance" ></input><br>
					<input type="submit" value="Confirm" id="b1" ></input>
					</form>
					<button id="b2" onclick="dis1()">Submit</button>
				</div>
			</div>
		</div>
	</body>
</html>