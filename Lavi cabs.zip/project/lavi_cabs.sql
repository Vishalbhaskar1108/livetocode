-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 10, 2017 at 02:37 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lavi_cabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `cab`
--

CREATE TABLE IF NOT EXISTS `cab` (
  `cabtype` varchar(20) DEFAULT NULL,
  `cabmodel` varchar(20) DEFAULT NULL,
  `cabnumber` varchar(20) NOT NULL,
  `available` int(1) DEFAULT NULL,
  PRIMARY KEY (`cabnumber`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cab`
--

INSERT INTO `cab` (`cabtype`, `cabmodel`, `cabnumber`, `available`) VALUES
('mini', 'Alto', 'TN100', 0),
('mini', 'Wagon R', 'TN101', 0),
('mini', 'Volkswagen Polo GT', 'TN102', 0),
('micro', 'Tata Nano', 'TN103', 0),
('micro', 'Tata Nano', 'TN104', 0),
('sedan', 'Hyundai Verna', 'TN105', 1),
('sedan', 'Hyundai Verna', 'TN106', 1),
('sedan', 'Honda City', 'TN107', 1),
('sedan', 'Hyundai Elantra', 'TN108', 1),
('sedan', 'Hyundai Elantra', 'TN109', 1),
('suv', 'Toyota Innova', 'TN110', 1),
('suv', 'Toyota Innova', 'TN111', 1),
('suv', 'Toyota Fortuner', 'TN112', 1),
('suv', 'Toyota Fortuner', 'TN113', 1),
('lux', 'BMW X5', 'TN114', 1),
('lux', 'BMW X5', 'TN115', 1),
('lux', 'Audi R8', 'TN116', 1),
('lux', 'Audi R8', 'TN117', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cabcost`
--

CREATE TABLE IF NOT EXISTS `cabcost` (
  `Name` varchar(20) DEFAULT NULL,
  `cost` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cabcost`
--

INSERT INTO `cabcost` (`Name`, `cost`) VALUES
('mini', 20),
('micro', 10),
('sedan', 30),
('suv', 40),
('lux', 200);

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE IF NOT EXISTS `driver` (
  `name` varchar(40) DEFAULT NULL,
  `id` varchar(10) NOT NULL,
  `available` int(1) DEFAULT NULL,
  `pass` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`name`, `id`, `available`, `pass`) VALUES
('Rahul Raj', '15BCE0045', 0, 'abc'),
('Mayank Verma', '15BCE0032', 0, 'abc'),
('Lalit Mohan', '15BCE0044', 0, 'abc'),
('Vishal Bhaskar', '15BCE0048', 0, 'abc'),
('Sparsh Goel', '15BCE0182', 0, 'jkl'),
('Karan Sharma', '15BCE0535', 0, 'ghi'),
('Abhinav Anand', '15BCE0060', 0, 'abc'),
('Akhil', '15BCE0028', 0, 'abc'),
('Paul', '15BCE0981', 0, 'def'),
('Harshit Sharma', '15BCE0506', 1, 'ghi'),
('Harshit Kumar', '15BCE0980', 1, 'def'),
('Abhishek Kumar', '15BCE0003', 1, 'abc'),
('Abhishek Ranjan', '15BCE0004', 1, 'abc'),
('Abhi Gaurav', '15BCE0005', 1, 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `travellog`
--

CREATE TABLE IF NOT EXISTS `travellog` (
  `passenger` varchar(40) DEFAULT NULL,
  `driverid` varchar(10) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `cost` int(10) DEFAULT NULL,
  `date1` varchar(10) DEFAULT NULL,
  `time1` varchar(10) DEFAULT NULL,
  `taxinum` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `travellog`
--

INSERT INTO `travellog` (`passenger`, `driverid`, `source`, `destination`, `cost`, `date1`, `time1`, `taxinum`) VALUES
('vishal', '15bce0045', 'vellore', 'chennai', 1370, '26-09-2017', '22:30', 'TN103'),
('aditya', '15BCE0044', 'vellore', 'katpadi', 80, '27-09-17', '9:38', 'TN103'),
('efkuhadius', '15BCE0044', 'vellore', 'katpadi', 80, '27-09-17', '12:70', 'TN103'),
('Abhishek', '15BCE0060', 'delhi', 'chennai', 1370, '10-11-17', '16:56', 'TN103'),
('vishal', '15BCE0028', 'delhi', 'chennai', 1370, '10-11-17', '16:66', 'TN104'),
('vishal', '15BCE0981', 'katpadi', 'chennai', 1370, '10-11-17', '16:66', '');
