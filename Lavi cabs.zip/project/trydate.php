<html>
<head>
</head>
<body>
<?php
$date=date("d") . "-" .date("m"). "-" .date("y");
echo($date);
$time=(date("G")+5). ":" .(date("i")+30);
echo("<br>".$time);

?>
</body>
</html>