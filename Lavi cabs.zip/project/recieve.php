<html>
	<head>
		<title>Lavi Cabs</title>
		<link rel="icon" type="image/png" href="car/a1.png">
		<style>
		#d1{
			background-color:black;
			width:102%;
			height:4px;
			margin-left:-8px;
			margin-top:-10px;
			}
		#d2{
			background-color:#4000FF;
			width:102%;
			height:100px;
			margin-left:-8px;
			border-bottom:solid 1px;
			}
		#d3{
			color:#B40404;
			font-size:400%;
			text-align:center;
			font-family:Lucida Calligraphy;
			padding-top:10px;
			text-shadow:2px 2px #FFFF00;
			}
		#d4{
			background-image:url('car/grab.jpg');
			width:102%;
			height:100%;
			margin-left:-8px;
			}
		#d5{
			width:28%;
			height:95%;
			background-color:#E0EFF3;
			margin-left:500px;
			border-radius:15px 30px 15px 30px;border-style:solid;border-width:1px;
			}
		#p1{
			text-align:center;
			font-size:180%;
			font-weight:bold;
			font-family:Informal Roman;
			margin-top:3%;
			}
		label{
				font-size:150%;
				margin-left:10px;
				font-family:Monotype Corsiva
				}
		input[type=text],select{
				width: 100%;
				padding: 12px 20px;
				margin: 8px 0;
				display: inline-block;
				border: 1px solid #ccc;
				border-radius: 4px;
				box-sizing: border-box;
				font-weight:bold;
				font-family:Comic Sans MS;
				}
			option{
				font-family:Comic Sans MS;
				font-weight:bold;
				}
			#d6{
				margin-top:-10px;
				text-align:center;
				font-size:180%;
				font-weight:bold;
				font-family:Informal Roman;
				}
			#b1,#b2{
				position:absolute;
				background-color: #4CAF50;
				border: none;
				color: white;
				padding: 16px 32px;
				text-decoration: none;
				cursor: pointer;
				margin-left:-80px;
				margin-top:200px;
				
				}
			
		</style>
		</script>
	</head>
	<body>
		<div id="d1">
		</div>
		<div id="d2">
			<div id="d3">
			Welcome Traveller!!
			</div>
		</div>
		<div id="d4">
			<br><br><div id="d5">
				<p id="p1">Your Details~</p>
				<div id="d6">
					Name: <?php echo $_POST["name"]; ?><br>
					Source: <?php echo $_POST["source"]; ?><br>
					Destination: <?php echo $_POST["destination"]; ?><br>
					Distance: <?php echo $_POST["distance"]; ?><br>
					Cabtype:<?php echo $_POST["cabtype"]; ?><br>
					Cost: <?php
					$cost=0;
					$dist=$_POST["distance"];
					$cab=$_POST["cabtype"];
					if($cab=="mini")
						$cost=$dist*20;
					elseif($cab=="micro")
						$cost=$dist*10;
					elseif($cab=="sedan")
						$cost=$dist*30;
					elseif($cab=="suv")
						$cost=$dist*40;
					elseif($cab=="lux")
						$cost=$dist*200;
					echo $cost;
					echo "<br>";
						
						$cab=$_POST["cabtype"];
						$name=$_POST["name"];
						$carno="";
						$driver="";
						$driverid="";
						$source=$_POST["source"];
						$dest=$_POST["destination"];
						$date=date("d") . "-" .date("m"). "-" .date("y");
						$time=(date("G")+5). ":" .(date("i")+30);
						$conn = new mysqli("localhost", "root", "", "lavi_cabs");
						if ($conn->connect_error) {
							die("Connection failed: " . $conn->connect_error);
						}
						$sql = "select cabnumber from cab where cabtype='". $cab ."' and available=1;";
						
						$result = $conn->query($sql);
						$row = $result->fetch_assoc();
						$carno=$row["cabnumber"];
						echo("Car Number:".$carno ."<br>");
						$sql1="UPDATE cab SET available=0 WHERE cabnumber='". $carno ."'";
						$conn->query($sql1);
						$sql3="select name,id from driver where available=1;";
						$result1 = $conn->query($sql3);
						$row1 = mysqli_fetch_array($result1);
						$driver=$row1["name"];
						$driverid=$row1["id"];
						echo("Driver's Name: ".$driver ."<br>");
						$sql4="UPDATE driver SET available=0 WHERE name='". $driver ."'";
						$conn->query($sql4);
						$sql5="insert into travellog values('". $name ."','". $driverid ."','" . $source ."','". $dest ."',".  $cost .",'". $date ."','".$time."','". $carno ."');";
						$conn->query($sql5);
					?>
					
				</div>
			</div>
		</div>
	</body>
</html>